package ece155b;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Mydialog extends JDialog{
	private JTextField idField ,nameField,priceField,amountField;
	private JLabel idLabelm,name,price,amount;
	public Mydialog() {
		JPanel panel=new JPanel();
		add(panel);
		
		
		
		
	}
}
